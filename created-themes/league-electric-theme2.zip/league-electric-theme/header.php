<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<!-- Top Bar -->
<div style="background:var(--color-secondary);padding:10px 0;">
  <div class="container" style="display:flex;justify-content:space-between;align-items:center;color:#fff;font-size:14px;flex-wrap:wrap;gap:12px;">
    <a href="/reviews" style="display:flex;align-items:center;gap:8px;color:#fff;">
      <span style="color:var(--color-gold);font-size:16px;">★★★★★</span>
      <strong>4.9</strong>
      <span style="opacity:0.75;">(97 Ratings &amp; Reviews)</span>
    </a>
    <span style="opacity:0.75;" class="hide-mobile">Serving Waco, TX &amp; Surrounding Areas</span>
    <div style="display:flex;align-items:center;gap:14px;">
      <span style="opacity:0.7;" class="hide-mobile">Call or Text</span>
      <a href="tel:2546266299" style="color:#fff;font-weight:700;font-size:17px;letter-spacing:0.02em;">(254) 626-7299</a>
      <a href="/contact" class="btn btn-primary" style="padding:8px 22px;font-size:13px;border-radius:5px;">Contact Us</a>
    </div>
  </div>
</div>

<!-- Navigation -->
<nav style="background:#fff;padding:0;box-shadow:0 2px 20px rgba(0,0,0,0.06);position:sticky;top:0;z-index:1000;">
  <div class="container" style="display:flex;justify-content:space-between;align-items:center;height:78px;">
    <a href="/" style="display:flex;align-items:center;">
      <img src="<?php echo get_template_directory_uri(); ?>/images/league-electric-logo.jpg" alt="League Electric" style="height:54px;width:auto;"/>
    </a>
    <div style="display:flex;gap:28px;align-items:center;" class="hide-mobile">
      <a href="#services" style="color:var(--color-secondary);font-weight:600;font-size:15px;padding:8px 0;border-bottom:2px solid transparent;transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--color-accent)'" onmouseout="this.style.borderColor='transparent'">Electrical Services</a>
      <a href="#specialty" style="color:var(--color-secondary);font-weight:600;font-size:15px;padding:8px 0;border-bottom:2px solid transparent;transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--color-accent)'" onmouseout="this.style.borderColor='transparent'">Specialty Services</a>
      <a href="#coupons" style="color:var(--color-secondary);font-weight:600;font-size:15px;padding:8px 0;border-bottom:2px solid transparent;transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--color-accent)'" onmouseout="this.style.borderColor='transparent'">Special Offers</a>
      <a href="/contact" style="color:var(--color-secondary);font-weight:600;font-size:15px;padding:8px 0;border-bottom:2px solid transparent;transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--color-accent)'" onmouseout="this.style.borderColor='transparent'">Contact</a>
      <a href="#about" style="color:var(--color-secondary);font-weight:600;font-size:15px;padding:8px 0;border-bottom:2px solid transparent;transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--color-accent)'" onmouseout="this.style.borderColor='transparent'">About</a>
      <a href="/contact" class="btn btn-primary" style="padding:10px 26px;font-size:14px;">Request Service</a>
    </div>
  </div>
</nav>
