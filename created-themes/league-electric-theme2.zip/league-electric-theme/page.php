<?php
/**
 * The page template.
 * Used for all standard WordPress pages.
 */
get_header();
?>
<main id="main" style="max-width:900px;margin:60px auto;padding:0 40px;min-height:60vh;">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            ?>
            <h1 style="font-size:38px;font-weight:700;margin-bottom:24px;line-height:1.2;">
                <?php the_title(); ?>
            </h1>
            <div style="font-size:17px;line-height:1.7;color:#444;">
                <?php the_content(); ?>
            </div>
            <?php
        endwhile;
    endif;
    ?>
</main>
<?php
get_footer();
