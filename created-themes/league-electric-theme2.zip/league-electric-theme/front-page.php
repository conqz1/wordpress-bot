<?php
/**
 * The front page template.
 * Homepage content — hero, services, CTA, etc.
 */
get_header();
?>
<!-- HERO SECTION -->
<section style="position:relative;min-height:680px;display:flex;align-items:center;overflow:hidden;">
  <img src="__IMG_hero_bg__" alt="Electrician working" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;"/>
  <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(26,26,26,0.85) 0%,rgba(139,46,26,0.6) 50%,rgba(0,0,0,0.4) 100%);z-index:1;"></div>
  <div class="container" style="position:relative;z-index:2;color:#fff;padding-top:100px;padding-bottom:100px;">
    <div class="fade-in-up">
      <p class="section-label" style="color:var(--color-gold);background:rgba(212,168,67,0.15);padding:6px 16px;border-radius:30px;display:inline-block;margin-bottom:20px;">⚡ Licensed &amp; Insured Electricians</p>
      <h1 style="font-size:58px;font-weight:900;line-height:1.08;margin-bottom:20px;max-width:650px;">Expert Electricians<br/>in Waco, TX</h1>
      <p style="font-size:20px;line-height:1.7;margin-bottom:16px;max-width:520px;opacity:0.9;">Your trusted partner for all things electrical since 2007. Residential &amp; commercial services with 24-hour emergency support.</p>
      <div style="display:flex;gap:10px;align-items:center;margin-bottom:36px;flex-wrap:wrap;">
        <span style="background:rgba(255,255,255,0.15);padding:6px 14px;border-radius:20px;font-size:13px;font-weight:600;">✓ 10% Off for New Customers</span>
        <span style="background:rgba(255,255,255,0.15);padding:6px 14px;border-radius:20px;font-size:13px;font-weight:600;">✓ Same-Day Service</span>
        <span style="background:rgba(255,255,255,0.15);padding:6px 14px;border-radius:20px;font-size:13px;font-weight:600;">✓ Military Discounts</span>
      </div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;">
        <a href="tel:2546267299" class="btn btn-primary" style="font-size:18px;padding:18px 40px;box-shadow:0 4px 20px rgba(232,76,61,0.4);">Call (254) 626-7299</a>
        <a href="/contact" class="btn btn-outline-white" style="font-size:18px;padding:18px 40px;">Request Service</a>
      </div>
    </div>
  </div>
</section>

<!-- INTRO / POWERING WACO -->
<section style="background:#fff;padding:100px 0;">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center;">
      <div>
        <p class="section-label" style="color:var(--color-accent);">About League Electric</p>
        <h2 class="section-title" style="margin-bottom:24px;">Powering Waco With Expert Electrical Solutions</h2>
        <div class="divider-accent"></div>
        <p style="color:#555;line-height:1.8;margin-bottom:20px;">League Electric is your trusted partner for all things electrical in Waco, TX and the surrounding areas. Since 2007, we have been lighting up homes and businesses with our exceptional skills and dedication to customer satisfaction.</p>
        <p style="color:#555;line-height:1.8;margin-bottom:28px;">Our electricians are fully licensed, insured, and efficient. We also offer free estimates and flexible scheduling to make your experience as hassle-free as possible. We're committed to providing top-notch service, consistently choosing quality, experience, and a team that truly cares about your satisfaction.</p>
        <a href="/contact" class="btn btn-primary">Get a Free Estimate</a>
      </div>
      <div style="position:relative;">
        <img src="__IMG_about__" alt="League Electric team at work" style="border-radius:16px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.12);"/>
        <div style="position:absolute;bottom:-20px;left:-20px;background:var(--color-primary);color:#fff;padding:24px 30px;border-radius:12px;box-shadow:0 8px 30px rgba(139,46,26,0.3);">
          <div style="font-size:36px;font-weight:900;line-height:1;">17+</div>
          <div style="font-size:14px;opacity:0.85;margin-top:4px;">Years of Experience</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WHY CHOOSE US -->
<section style="background:var(--color-light);padding:100px 0;">
  <div class="container">
    <div style="text-align:center;margin-bottom:60px;">
      <p class="section-label" style="color:var(--color-primary);">Why Choose League Electric</p>
      <h2 class="section-title" style="margin:0 auto;">Built on Trust, Quality &amp; Reliability</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:24px;">
      <div class="card" style="text-align:center;border-top:4px solid var(--color-accent);">
        <div style="font-size:44px;margin-bottom:16px;">💰</div>
        <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">10% Off for New Customers</h3>
        <p style="color:#666;font-size:15px;line-height:1.7;">Welcome discount for all first-time customers on any service.</p>
      </div>
      <div class="card" style="text-align:center;border-top:4px solid var(--color-accent);">
        <div style="font-size:44px;margin-bottom:16px;">🎖️</div>
        <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">10% Military Discount</h3>
        <p style="color:#666;font-size:15px;line-height:1.7;">We proudly support those who serve with special military pricing.</p>
      </div>
      <div class="card" style="text-align:center;border-top:4px solid var(--color-accent);">
        <div style="font-size:44px;margin-bottom:16px;">🏆</div>
        <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">45+ Years Experience</h3>
        <p style="color:#666;font-size:15px;line-height:1.7;">Decades of combined experience in residential and commercial electrical.</p>
      </div>
      <div class="card" style="text-align:center;border-top:4px solid var(--color-accent);">
        <div style="font-size:44px;margin-bottom:16px;">⏱️</div>
        <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">Response Within 24 Hours</h3>
        <p style="color:#666;font-size:15px;line-height:1.7;">Prompt arrival and one-year labor and material warranty on all work.</p>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES SECTION -->
<section id="services" style="background:#fff;padding:100px 0;">
  <div class="container">
    <div style="text-align:center;margin-bottom:60px;">
      <p class="section-label" style="color:var(--color-accent);">What We Do</p>
      <h2 class="section-title" style="margin:0 auto;">Our Electrical Services</h2>
      <p class="section-subtitle" style="margin:16px auto 0;">From new construction to emergency repairs, League Electric delivers expert solutions for every electrical need.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:32px;">
      <div class="card" style="display:flex;gap:24px;align-items:flex-start;padding:40px 32px;">
        <div style="min-width:64px;height:64px;background:var(--color-warm);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:32px;">🏠</div>
        <div>
          <h3 style="font-size:22px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">Residential Electrical</h3>
          <p style="color:#555;line-height:1.7;font-size:15px;margin-bottom:14px;">Panel upgrades, outlet installations, wiring repairs, whole-home rewiring, ceiling fan installs, and everything your home's electrical system needs.</p>
          <a href="/services" style="color:var(--color-accent);font-weight:600;font-size:15px;">Learn More →</a>
        </div>
      </div>
      <div class="card" style="display:flex;gap:24px;align-items:flex-start;padding:40px 32px;">
        <div style="min-width:64px;height:64px;background:var(--color-warm);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:32px;">🏢</div>
        <div>
          <h3 style="font-size:22px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">Commercial Electrical</h3>
          <p style="color:#555;line-height:1.7;font-size:15px;margin-bottom:14px;">Office build-outs, commercial lighting, electrical code compliance, and commercial-grade wiring for businesses of all sizes in the Waco area.</p>
          <a href="/services" style="color:var(--color-accent);font-weight:600;font-size:15px;">Learn More →</a>
        </div>
      </div>
      <div class="card" style="display:flex;gap:24px;align-items:flex-start;padding:40px 32px;">
        <div style="min-width:64px;height:64px;background:var(--color-warm);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:32px;">🏗️</div>
        <div>
          <h3 style="font-size:22px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">New Construction</h3>
          <p style="color:#555;line-height:1.7;font-size:15px;margin-bottom:14px;">Trusted electrical work for new construction projects — from custom homes to commercial developments. We handle every phase from the ground up.</p>
          <a href="/services" style="color:var(--color-accent);font-weight:600;font-size:15px;">Learn More →</a>
        </div>
      </div>
      <div id="specialty" class="card" style="display:flex;gap:24px;align-items:flex-start;padding:40px 32px;">
        <div style="min-width:64px;height:64px;background:var(--color-warm);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:32px;">✨</div>
        <div>
          <h3 style="font-size:22px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);">Specialty Electrical Services</h3>
          <p style="color:#555;line-height:1.7;font-size:15px;margin-bottom:14px;">Energy-efficient lighting, generator installation, EV charger setup, smart home wiring, and custom electrical solutions for modern living.</p>
          <a href="/services" style="color:var(--color-accent);font-weight:600;font-size:15px;">Learn More →</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- EMERGENCY SERVICES -->
<section style="background:var(--color-secondary);padding:100px 0;position:relative;overflow:hidden;">
  <div style="position:absolute;top:0;right:0;width:40%;height:100%;overflow:hidden;" class="hide-mobile">
    <img src="__IMG_emergency__" alt="Emergency electrical service" style="width:100%;height:100%;object-fit:cover;opacity:0.3;"/>
  </div>
  <div class="container" style="position:relative;z-index:2;">
    <div style="max-width:640px;">
      <p class="section-label" style="color:var(--color-gold);">24/7 Available</p>
      <h2 class="section-title" style="color:#fff;margin-bottom:24px;">Emergency Services You Can Count On, Day or Night</h2>
      <div class="divider-accent"></div>
      <p style="color:rgba(255,255,255,0.8);line-height:1.8;margin-bottom:20px;font-size:17px;">Electrical emergencies can strike at the most inconvenient times — a sudden power outage, a sparking outlet, or a storm damaging your electrical systems. That's why League Electric offers a full list of electrical services to keep you safe and in power.</p>
      <p style="color:rgba(255,255,255,0.8);line-height:1.8;margin-bottom:32px;font-size:17px;">We arrive quickly, equipped with the tools and expertise to solve your immediate electrical problems. Our electricians don't just fix the issue — they make sure you understand what happened and how to prevent it in the future.</p>
      <div style="display:flex;gap:16px;flex-wrap:wrap;">
        <a href="tel:2546267299" class="btn btn-primary" style="font-size:17px;padding:16px 36px;">Call Now: (254) 626-7299</a>
        <a href="/contact" class="btn btn-outline-white" style="font-size:17px;padding:16px 36px;">Request Emergency Service</a>
      </div>
    </div>
  </div>
</section>

<!-- ENERGY SAVINGS -->
<section style="background:var(--color-light);padding:100px 0;">
  <div class="container">
    <div style="text-align:center;margin-bottom:60px;">
      <p class="section-label" style="color:var(--color-primary);">Save Money &amp; Energy</p>
      <h2 class="section-title">Energy-Saving Solutions From an Expert Electrician</h2>
      <p class="section-subtitle" style="margin:16px auto 0;">Smart upgrades that put money back in your pocket while reducing your environmental footprint.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:28px;">
      <div class="card" style="text-align:center;">
        <div style="width:72px;height:72px;background:var(--color-warm);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto 20px;">💡</div>
        <h3 style="font-size:19px;font-weight:700;margin-bottom:10px;">LED Lighting Upgrades</h3>
        <p style="color:#666;line-height:1.7;font-size:15px;">Upgrade to energy-efficient LED lighting for homes and businesses. Reduce energy bills while improving light quality.</p>
      </div>
      <div class="card" style="text-align:center;">
        <div style="width:72px;height:72px;background:var(--color-warm);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto 20px;">⚡</div>
        <h3 style="font-size:19px;font-weight:700;margin-bottom:10px;">Smart Panel Upgrades</h3>
        <p style="color:#666;line-height:1.7;font-size:15px;">Modern electrical panels that optimize energy distribution and support today's high-demand homes and businesses.</p>
      </div>
      <div class="card" style="text-align:center;">
        <div style="width:72px;height:72px;background:var(--color-warm);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto 20px;">🌱</div>
        <h3 style="font-size:19px;font-weight:700;margin-bottom:10px;">Green Building Solutions</h3>
        <p style="color:#666;line-height:1.7;font-size:15px;">Sustainable electrical solutions for businesses looking to reduce carbon footprint and achieve sustainability goals.</p>
      </div>
    </div>
  </div>
</section>

<!-- CTA - GET STARTED -->
<section style="background:var(--color-primary);padding:100px 0;position:relative;overflow:hidden;">
  <div style="position:absolute;inset:0;background:url('data:image/svg+xml,%3Csvg width=&quot;60&quot; height=&quot;60&quot; viewBox=&quot;0 0 60 60&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;%3E%3Cg fill=&quot;none&quot; fill-rule=&quot;evenodd&quot;%3E%3Cg fill=&quot;%23ffffff&quot; fill-opacity=&quot;0.04&quot;%3E%3Cpath d=&quot;M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z&quot;/%3E%3C/g%3E%3C/g%3E%3C/svg%3E');"></div>
  <div class="container" style="position:relative;z-index:2;">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center;">
      <div>
        <p class="section-label" style="color:var(--color-gold);">Ready to Get Started?</p>
        <h2 style="font-size:42px;font-weight:800;color:#fff;line-height:1.15;margin-bottom:20px;">Let's Get Started on Your Electrical Project Today</h2>
        <p style="color:rgba(255,255,255,0.85);font-size:18px;line-height:1.8;margin-bottom:32px;">Whether it comes to electrical work, quality, safety, and reliability matter — and that's what League Electric delivers. Don't put off your electrical needs. Reach out today for a free estimate and same-day service availability.</p>
        <div style="display:flex;gap:16px;flex-wrap:wrap;">
          <a href="tel:2546267299" class="btn" style="background:#fff;color:var(--color-primary);font-size:18px;padding:18px 40px;">Call (254) 626-7299</a>
          <a href="/contact" class="btn btn-outline-white" style="font-size:18px;padding:18px 40px;">Request Estimate</a>
        </div>
      </div>
      <div style="background:rgba(255,255,255,0.1);border-radius:16px;padding:40px;backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.15);">
        <h3 style="color:#fff;font-size:22px;font-weight:700;margin-bottom:24px;text-align:center;">Why League Electric?</h3>
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div style="display:flex;gap:14px;align-items:center;">
            <div style="min-width:40px;height:40px;background:var(--color-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">✓</div>
            <span style="color:rgba(255,255,255,0.9);font-size:16px;">Family-owned business with local roots</span>
          </div>
          <div style="display:flex;gap:14px;align-items:center;">
            <div style="min-width:40px;height:40px;background:var(--color-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">✓</div>
            <span style="color:rgba(255,255,255,0.9);font-size:16px;">Transparent pricing, no hidden fees</span>
          </div>
          <div style="display:flex;gap:14px;align-items:center;">
            <div style="min-width:40px;height:40px;background:var(--color-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">✓</div>
            <span style="color:rgba(255,255,255,0.9);font-size:16px;">Licensed, insured &amp; background checked</span>
          </div>
          <div style="display:flex;gap:14px;align-items:center;">
            <div style="min-width:40px;height:40px;background:var(--color-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">✓</div>
            <span style="color:rgba(255,255,255,0.9);font-size:16px;">Free same-day estimates available</span>
          </div>
          <div style="display:flex;gap:14px;align-items:center;">
            <div style="min-width:40px;height:40px;background:var(--color-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">✓</div>
            <span style="color:rgba(255,255,255,0.9);font-size:16px;">Multiple discounts &amp; flexible scheduling</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- COUPONS / SPECIAL OFFERS -->
<section id="coupons" style="background:#fff;padding:100px 0;">
  <div class="container">
    <div style="text-align:center;margin-bottom:60px;">
      <p class="section-label" style="color:var(--color-accent);">Special Offers</p>
      <h2 class="section-title">Exclusive Savings for You</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:32px;">
      <div style="background:linear-gradient(135deg,var(--color-warm) 0%,#fff 100%);border-radius:16px;padding:44px 36px;border:2px dashed var(--color-accent);text-align:center;transition:transform 0.3s;" onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform=''">
        <div style="background:var(--color-accent);color:#fff;display:inline-block;padding:8px 20px;border-radius:30px;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:20px;">Seniors</div>
        <h3 style="font-size:28px;font-weight:800;color:var(--color-primary);margin-bottom:12px;">Seniors Save 10% Today!</h3>
        <p style="color:#555;line-height:1.7;margin-bottom:24px;">League Electric values our senior customers. Enjoy a 10% discount on all electrical services. Call us today to schedule your appointment.</p>
        <a href="tel:2546267299" class="btn btn-primary">Call (254) 626-7299</a>
      </div>
      <div style="background:linear-gradient(135deg,var(--color-warm) 0%,#fff 100%);border-radius:16px;padding:44px 36px;border:2px dashed var(--color-accent);text-align:center;transition:transform 0.3s;" onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform=''">
        <div style="background:var(--color-accent);color:#fff;display:inline-block;padding:8px 20px;border-radius:30px;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:20px;">New Customers</div>
        <h3 style="font-size:28px;font-weight:800;color:var(--color-primary);margin-bottom:12px;">New Customers? 10% Off!</h3>
        <p style="color:#555;line-height:1.7;margin-bottom:24px;">We welcome first-time customers with a special 10% discount. Contact us today to claim your new customer discount on any service.</p>
        <a href="tel:2546267299" class="btn btn-primary">Call (254) 626-7299</a>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section style="background:var(--color-light);padding:100px 0;">
  <div class="container">
    <div style="text-align:center;margin-bottom:60px;">
      <p class="section-label" style="color:var(--color-primary);">Customer Reviews</p>
      <h2 class="section-title">Here's What Our Satisfied Customers Are Saying...</h2>
      <p class="section-subtitle" style="margin:16px auto 0;">At League Electric, we take pride in providing exceptional electrical services. Read what our customers say about their experience.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:28px;">
      <div class="card" style="border-left:4px solid var(--color-accent);position:relative;">
        <div style="color:var(--color-gold);font-size:20px;margin-bottom:14px;">★★★★★</div>
        <p style="font-style:italic;line-height:1.8;margin-bottom:20px;color:#444;font-size:15px;">"League Electric did an amazing job rewiring our older home. They were professional, clean, and finished ahead of schedule. Highly recommend them for any electrical work!"</p>
        <strong style="color:var(--color-secondary);font-size:15px;">— Sarah M., Waco</strong>
      </div>
      <div class="card" style="border-left:4px solid var(--color-accent);position:relative;">
        <div style="color:var(--color-gold);font-size:20px;margin-bottom:14px;">★★★★★</div>
        <p style="font-style:italic;line-height:1.8;margin-bottom:20px;color:#444;font-size:15px;">"Called for an emergency late at night and they responded within the hour. Fixed the issue quickly and explained everything thoroughly. Couldn't ask for better service."</p>
        <strong style="color:var(--color-secondary);font-size:15px;">— James R., McGregor</strong>
      </div>
      <div class="card" style="border-left:4px solid var(--color-accent);position:relative;">
        <div style="color:var(--color-gold);font-size:20px;margin-bottom:14px;">★★★★★</div>
        <p style="font-style:italic;line-height:1.8;margin-bottom:20px;color:#444;font-size:15px;">"We used League Electric for our new construction project. From start to finish, they were reliable, knowledgeable, and delivered excellent workmanship. A+ experience!"</p>
        <strong style="color:var(--color-secondary);font-size:15px;">— David &amp; Karen T., Hewitt</strong>
      </div>
    </div>
    <div style="text-align:center;margin-top:40px;">
      <a href="/reviews" class="btn btn-secondary">Read All 97 Reviews</a>
    </div>
  </div>
</section>

<!-- BLOG POSTS PREVIEW -->
<section style="background:#fff;padding:100px 0;">
  <div class="container">
    <div style="text-align:center;margin-bottom:60px;">
      <p class="section-label" style="color:var(--color-accent);">Expert Insights</p>
      <h2 class="section-title">Recent Blog Posts</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:28px;">
      <div class="card" style="padding:0;overflow:hidden;">
        <img src="__IMG_blog1__" alt="Electrical checklist" style="width:100%;height:200px;object-fit:cover;"/>
        <div style="padding:28px;">
          <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);line-height:1.4;">How Hiring an Electrician Can Save You Money on Average Projects</h3>
          <p style="color:#666;font-size:14px;line-height:1.7;margin-bottom:14px;">If you are considering hiring an expert electrician instead of DIY, here's how it saves you money long-term.</p>
          <a href="/blog" style="color:var(--color-accent);font-weight:600;font-size:14px;">Read More →</a>
        </div>
      </div>
      <div class="card" style="padding:0;overflow:hidden;">
        <img src="__IMG_blog2__" alt="Residential electrician" style="width:100%;height:200px;object-fit:cover;"/>
        <div style="padding:28px;">
          <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);line-height:1.4;">When Should I Call a Residential Electrician for Help?</h3>
          <p style="color:#666;font-size:14px;line-height:1.7;margin-bottom:14px;">Let's go over when it's time to call a residential electrician versus when you can handle it yourself.</p>
          <a href="/blog" style="color:var(--color-accent);font-weight:600;font-size:14px;">Read More →</a>
        </div>
      </div>
      <div class="card" style="padding:0;overflow:hidden;">
        <img src="__IMG_blog3__" alt="Home electrification" style="width:100%;height:200px;object-fit:cover;"/>
        <div style="padding:28px;">
          <h3 style="font-size:18px;font-weight:700;margin-bottom:10px;color:var(--color-secondary);line-height:1.4;">Full Home Electrification Could Cost $96 Billion in U.S. Utility Costs by 2050</h3>
          <p style="color:#666;font-size:14px;line-height:1.7;margin-bottom:14px;">Understanding the future of home electrification for greater efficiency, solar integration, and energy savings.</p>
          <a href="/blog" style="color:var(--color-accent);font-weight:600;font-size:14px;">Read More →</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PARTNERS / BRANDS -->
<section style="background:var(--color-light);padding:60px 0;">
  <div class="container" style="text-align:center;">
    <p style="font-size:14px;font-weight:600;text-transform:uppercase;letter-spacing:0.1em;color:#999;margin-bottom:30px;">Trusted Brands We Work With</p>
    <div style="display:flex;justify-content:center;align-items:center;gap:50px;flex-wrap:wrap;opacity:0.5;filter:grayscale(1);">
      <img src="__IMG_brand_kohler__" alt="Kohler" style="height:36px;width:auto;"/>
      <img src="__IMG_brand_generac__" alt="Generac" style="height:36px;width:auto;"/>
    </div>
  </div>
</section>

<!-- FINAL CTA BAND -->
<section style="background:var(--color-accent);padding:80px 0;text-align:center;">
  <div class="container">
    <h2 style="font-size:40px;font-weight:800;color:#fff;margin-bottom:16px;">Ready to Power Your Next Project?</h2>
    <p style="font-size:19px;color:rgba(255,255,255,0.9);margin-bottom:36px;max-width:540px;margin-left:auto;margin-right:auto;">Contact League Electric today for a free estimate. Same-day appointments available.</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
      <a href="tel:2546267299" class="btn" style="background:#fff;color:var(--color-accent);font-size:18px;padding:18px 44px;font-weight:700;">Call (254) 626-7299</a>
      <a href="/contact" class="btn" style="background:transparent;color:#fff;border:2px solid #fff;font-size:18px;padding:18px 44px;">Send a Message</a>
    </div>
  </div>
</section>
<?php
get_footer();
