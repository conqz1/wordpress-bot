<footer style="background:var(--color-secondary);padding:80px 0 0;color:#fff;">
  <div class="container">
    <div style="display:grid;grid-template-columns:2.5fr 1fr 1fr 1.5fr;gap:50px;margin-bottom:60px;">
      <div>
        <img src="<?php echo get_template_directory_uri(); ?>/images/league-electric-logo.jpg" alt="League Electric" style="height:52px;margin-bottom:20px;filter:brightness(0) invert(1);"/>
        <p style="opacity:0.65;line-height:1.8;max-width:320px;font-size:15px;">Serving the Waco, TX area. League Electric specializes in residential, commercial, and specialty electrical services. Multiple discounts offered. Free same-day estimates. Call us today.</p>
        <a href="/reviews" class="btn btn-primary" style="margin-top:20px;padding:10px 24px;font-size:14px;">Watch Video</a>
      </div>
      <div>
        <h4 style="font-weight:700;margin-bottom:20px;font-size:16px;color:var(--color-accent);">Serving Area</h4>
        <div style="display:flex;flex-direction:column;gap:10px;opacity:0.7;">
          <a href="#" style="color:#fff;font-size:15px;transition:opacity 0.2s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">Waco</a>
          <a href="#" style="color:#fff;font-size:15px;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">And surrounding areas</a>
        </div>
      </div>
      <div>
        <h4 style="font-weight:700;margin-bottom:20px;font-size:16px;color:var(--color-accent);">Quick Links</h4>
        <div style="display:flex;flex-direction:column;gap:10px;opacity:0.7;">
          <a href="/services" style="color:#fff;font-size:15px;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">Electrical Services</a>
          <a href="/services" style="color:#fff;font-size:15px;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">Electrical Inspections</a>
          <a href="/services" style="color:#fff;font-size:15px;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">Wiring Installation</a>
          <a href="/services" style="color:#fff;font-size:15px;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">Outdoor Lighting</a>
          <a href="/about" style="color:#fff;font-size:15px;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">About</a>
        </div>
      </div>
      <div>
        <h4 style="font-weight:700;margin-bottom:20px;font-size:16px;color:var(--color-accent);">Contact Us</h4>
        <div style="opacity:0.7;font-size:15px;line-height:2.2;">
          <p><strong style="color:var(--color-accent);">(254) 626-7299</strong></p>
          <p>Waco, TX</p>
          <a href="/contact" style="color:#fff;">Send a Message</a>
        </div>
        <div style="margin-top:20px;">
          <h4 style="font-weight:700;margin-bottom:10px;font-size:14px;color:var(--color-accent);">Business Hours</h4>
          <div style="opacity:0.7;font-size:14px;line-height:1.9;">
            <p>Mon – Sat: 8:00 am – 5:00 pm</p>
            <p style="font-size:13px;color:var(--color-gold);opacity:1;">⚡ 24/7 Emergency Services Available<br/>Same Day Appointments Available</p>
          </div>
        </div>
      </div>
    </div>
    <div style="border-top:1px solid rgba(255,255,255,0.1);padding:28px 0;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
      <p style="opacity:0.45;font-size:13px;">© <?php echo date('Y'); ?> League Electric. All rights reserved.</p>
      <div style="display:flex;gap:24px;opacity:0.45;font-size:13px;">
        <a href="/privacy" style="color:#fff;">Privacy Policy</a>
        <a href="/terms" style="color:#fff;">Terms of Service</a>
        <a href="/sitemap" style="color:#fff;">Sitemap</a>
      </div>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
